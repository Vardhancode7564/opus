"""GitHub Project Collector - Fetches student project repositories via GitHub API."""

import requests
import time
import logging

from config import GITHUB_API_URL

logger = logging.getLogger(__name__)


def search_github_repos(query="student project", max_results=30):
    """
    Search GitHub for repositories matching the query.
    Returns a list of project dicts with title, description, language, readme, link.
    """
    projects = []
    per_page = min(max_results, 30)
    page = 1
    fetched = 0

    while fetched < max_results:
        params = {
            "q": query,
            "sort": "stars",
            "order": "desc",
            "per_page": per_page,
            "page": page,
        }
        try:
            resp = requests.get(
                f"{GITHUB_API_URL}/search/repositories",
                params=params,
                timeout=15,
            )
            if resp.status_code == 403:
                logger.warning("GitHub API rate limit hit. Stopping collection.")
                break
            resp.raise_for_status()
            data = resp.json()
            items = data.get("items", [])
            if not items:
                break

            for repo in items:
                readme_content = _fetch_readme(repo["full_name"])
                project = {
                    "project_title": repo.get("name", ""),
                    "description": repo.get("description", "") or "",
                    "technologies": repo.get("language", "Unknown") or "Unknown",
                    "source": "github",
                    "project_link": repo.get("html_url", ""),
                    "readme": readme_content,
                }
                projects.append(project)
                fetched += 1
                if fetched >= max_results:
                    break
            page += 1
            time.sleep(1)  # respect rate limits
        except requests.RequestException as e:
            logger.error(f"GitHub API error: {e}")
            break

    return projects


def _fetch_readme(full_name):
    """Fetch the README content for a repository."""
    try:
        resp = requests.get(
            f"{GITHUB_API_URL}/repos/{full_name}/readme",
            headers={"Accept": "application/vnd.github.v3.raw"},
            timeout=10,
        )
        if resp.status_code == 200:
            # Truncate to keep things manageable
            return resp.text[:2000]
    except requests.RequestException:
        pass
    return ""


def fetch_repo_details(repo_url):
    """Fetch details for a single GitHub repository URL."""
    # Extract owner/repo from URL
    parts = repo_url.rstrip("/").split("/")
    if len(parts) < 2:
        return None
    owner, repo = parts[-2], parts[-1]

    try:
        resp = requests.get(
            f"{GITHUB_API_URL}/repos/{owner}/{repo}", timeout=10
        )
        resp.raise_for_status()
        data = resp.json()
        readme = _fetch_readme(f"{owner}/{repo}")
        return {
            "project_title": data.get("name", ""),
            "description": data.get("description", "") or "",
            "technologies": data.get("language", "Unknown") or "Unknown",
            "source": "github",
            "project_link": data.get("html_url", ""),
            "readme": readme,
        }
    except requests.RequestException as e:
        logger.error(f"Error fetching repo {repo_url}: {e}")
        return None
